Some packaging interface functions of AI Models API

Steps to Build this Wheel：
- Enter folder: ./Build_Wheel
- Run command: python -m build