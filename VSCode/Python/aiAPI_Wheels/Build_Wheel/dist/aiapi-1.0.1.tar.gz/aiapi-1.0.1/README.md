Some packaging interface functions of AI Models API

Steps to Build this Wheel：
- Enter folder: ./Build_Wheel
- Run command: python -m build

FIX:
version 1.0: 
    Init
version 1.0.1: 
    Fix the issue where the stream mode chunk is empty.